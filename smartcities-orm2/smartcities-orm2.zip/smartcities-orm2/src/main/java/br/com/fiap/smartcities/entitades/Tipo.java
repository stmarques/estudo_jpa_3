package br.com.fiap.smartcities.entitades;

public enum Tipo {
	Hotel, Receptivo,Cia_Aerea;

}
